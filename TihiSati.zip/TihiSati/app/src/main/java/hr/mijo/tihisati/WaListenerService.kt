package hr.mijo.tihisati

import android.app.Notification
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * WhatsApp obavijesti su u samom WhatsAppu postavljene na tiho (ton "Ništa", bez vibracije).
 * Ovaj servis vidi svaku novu obavijest i sam pusti zvuk + vibraciju — osim za razgovore
 * koji imaju pravilo i trenutno su izvan svog vremenskog prozora.
 */
class WaListenerService : NotificationListenerService() {

    private val lastWhen = HashMap<String, Long>()
    private var lastAlertAt = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in WA_PACKAGES) return

        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return // sažetak "3 nove poruke"
        if (sbn.isOngoing) return // pozivi u tijeku, "provjera novih poruka" i sl.
        if (n.category == Notification.CATEGORY_CALL) return // pozive ne diramo

        // WhatsApp često ponovno objavi istu obavijest bez nove poruke — zvoni samo kad se promijeni vrijeme.
        val previous = lastWhen.put(sbn.key, n.`when`)
        if (previous == n.`when`) return

        val extras = n.extras
        val titles = listOfNotNull(
            extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
        )

        val rule = RuleStore.load(this).firstOrNull { it.matches(titles) }
        if (rule != null && !rule.isActiveNow()) {
            if (rule.hide) cancelNotification(sbn.key)
            return // izvan vremena: bez zvuka
        }

        alert()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        lastWhen.remove(sbn.key)
    }

    private fun alert() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastAlertAt < 1500) return // više poruka odjednom = jedan zvuk
        lastAlertAt = now

        // Poštuj "Ne ometaj".
        if (currentInterruptionFilter > NotificationListenerService.INTERRUPTION_FILTER_ALL) return

        when (getSystemService(AudioManager::class.java).ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> { playSound(); vibrate() }
            AudioManager.RINGER_MODE_VIBRATE -> vibrate()
            else -> Unit // nečujno
        }
    }

    private fun playSound() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) ?: return
        val ringtone = RingtoneManager.getRingtone(this, uri) ?: return
        ringtone.audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        ringtone.play()
    }

    private fun vibrate() {
        vibrator()?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 180, 120, 180), -1))
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            getSystemService(Vibrator::class.java)
        }

    companion object {
        val WA_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
    }
}
