package hr.mijo.tihisati

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Bit 0 = ponedjeljak … bit 6 = nedjelja. */
const val WORKDAYS = 0b0011111
const val ALL_DAYS = 0b1111111
val DAY_NAMES = arrayOf("Pon", "Uto", "Sri", "Čet", "Pet", "Sub", "Ned")

/**
 * Pravilo za jedan razgovor: obavijesti zvone samo unutar [startMin, endMin) u odabrane dane.
 * Izvan tog prozora obavijest ostaje tiha, ili se potpuno makne ako je [hide] = true.
 */
data class Rule(
    val id: Long,
    val chat: String,
    val startMin: Int,
    val endMin: Int,
    val days: Int,
    val hide: Boolean,
) {
    fun matches(titles: List<String>): Boolean =
        titles.any { it.contains(chat, ignoreCase = true) }

    fun isActiveNow(cal: Calendar = Calendar.getInstance()): Boolean {
        val dayBit = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Calendar: NED=1, PON=2 → PON=0 … NED=6
        val inDay = (days and (1 shl dayBit)) != 0
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val inTime = if (startMin <= endMin) {
            now >= startMin && now < endMin
        } else { // prozor preko ponoći, npr. 22:00–06:00
            now >= startMin || now < endMin
        }
        return inDay && inTime
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("chat", chat)
        .put("start", startMin)
        .put("end", endMin)
        .put("days", days)
        .put("hide", hide)

    companion object {
        fun fromJson(o: JSONObject) = Rule(
            id = o.getLong("id"),
            chat = o.getString("chat"),
            startMin = o.getInt("start"),
            endMin = o.getInt("end"),
            days = o.optInt("days", WORKDAYS),
            hide = o.optBoolean("hide", false),
        )
    }
}

object RuleStore {
    private const val PREFS = "tihi_sati"
    private const val KEY = "rules"

    fun load(ctx: Context): List<Rule> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { Rule.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(it.toJson()) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, arr.toString())
            .apply()
    }
}

fun fmt(min: Int): String = "%02d:%02d".format(min / 60, min % 60)

fun daysLabel(days: Int): String = when (days) {
    WORKDAYS -> "Pon–Pet"
    ALL_DAYS -> "Svaki dan"
    else -> DAY_NAMES.filterIndexed { i, _ -> (days and (1 shl i)) != 0 }.joinToString(", ")
}
