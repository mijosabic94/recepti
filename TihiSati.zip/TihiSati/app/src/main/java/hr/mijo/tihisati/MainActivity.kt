package hr.mijo.tihisati

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        status = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(8)) }
        root.addView(status)

        root.addView(button("1. Uključi pristup obavijestima") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("2. Otvori WhatsApp i utišaj ga") { openWhatsApp() })
        root.addView(note(
            "U WhatsAppu: Postavke → Obavijesti. Za Poruke i za Grupe stavi ton obavijesti na " +
                "\"Ništa\" i vibraciju na \"Isključeno\". Od tada zvuk daje ova aplikacija, i to samo kad smije."
        ))

        root.addView(header("Razgovori s rasporedom"))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(button("+ Dodaj razgovor") { editRule(null) })
        root.addView(note("Razgovori koji nisu na popisu zvone normalno."))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = if (enabled) {
            "✅ Pristup obavijestima je uključen"
        } else {
            "⚠️ Pristup obavijestima nije uključen (korak 1)"
        }

        list.removeAllViews()
        val rules = RuleStore.load(this)
        if (rules.isEmpty()) list.addView(note("Još nema pravila."))
        rules.forEach { r ->
            list.addView(TextView(this).apply {
                text = "${r.chat}\n${daysLabel(r.days)}  ${fmt(r.startMin)}–${fmt(r.endMin)}" +
                    "  ·  izvan vremena: ${if (r.hide) "sakrij" else "tiho"}"
                textSize = 16f
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { editRule(r) }
            })
        }
    }

    private fun editRule(existing: Rule?) {
        val ctx = this
        var start = existing?.startMin ?: (8 * 60)
        var end = existing?.endMin ?: (16 * 60)
        val existingDays = existing?.days ?: WORKDAYS

        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        val name = EditText(ctx).apply {
            hint = "Naziv razgovora (ili dio naziva)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(existing?.chat ?: "")
        }
        box.addView(name)

        val startBtn = Button(ctx).apply { isAllCaps = false }
        val endBtn = Button(ctx).apply { isAllCaps = false }
        fun updateLabels() {
            startBtn.text = "Od ${fmt(start)}"
            endBtn.text = "Do ${fmt(end)}"
        }
        updateLabels()
        startBtn.setOnClickListener {
            TimePickerDialog(ctx, { _, h, m -> start = h * 60 + m; updateLabels() }, start / 60, start % 60, true).show()
        }
        endBtn.setOnClickListener {
            TimePickerDialog(ctx, { _, h, m -> end = h * 60 + m; updateLabels() }, end / 60, end % 60, true).show()
        }
        box.addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(startBtn)
            addView(endBtn)
        })

        val dayRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val checks = DAY_NAMES.mapIndexed { i, d ->
            CheckBox(ctx).apply {
                text = d
                isChecked = (existingDays and (1 shl i)) != 0
            }
        }
        checks.forEach { dayRow.addView(it) }
        box.addView(HorizontalScrollView(ctx).apply { addView(dayRow) })

        val hide = CheckBox(ctx).apply {
            text = "Izvan vremena potpuno sakrij obavijest (inače ostaje, ali tiho)"
            isChecked = existing?.hide ?: false
        }
        box.addView(hide)

        val builder = AlertDialog.Builder(ctx)
            .setTitle(if (existing == null) "Novi razgovor" else "Uredi razgovor")
            .setView(box)
            .setPositiveButton("Spremi", null)
            .setNegativeButton("Odustani", null)
        if (existing != null) {
            builder.setNeutralButton("Obriši") { _, _ ->
                RuleStore.save(ctx, RuleStore.load(ctx).filter { it.id != existing.id })
                refresh()
            }
        }

        val dialog = builder.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val chat = name.text.toString().trim()
            val days = checks.foldIndexed(0) { i, acc, c -> if (c.isChecked) acc or (1 shl i) else acc }
            when {
                chat.isEmpty() -> name.error = "Upiši naziv razgovora"
                days == 0 -> toast("Odaberi barem jedan dan")
                else -> {
                    val rule = Rule(existing?.id ?: System.currentTimeMillis(), chat, start, end, days, hide.isChecked)
                    RuleStore.save(ctx, RuleStore.load(ctx).filter { it.id != rule.id } + rule)
                    refresh()
                    dialog.dismiss()
                }
            }
        }
    }

    private fun openWhatsApp() {
        val intent = WaListenerService.WA_PACKAGES.firstNotNullOfOrNull {
            packageManager.getLaunchIntentForPackage(it)
        }
        if (intent != null) startActivity(intent) else toast("WhatsApp nije pronađen")
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        alpha = 0.7f
        setPadding(0, dp(4), 0, dp(12))
    }

    private fun header(t: String) = TextView(this).apply {
        text = t
        textSize = 18f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
