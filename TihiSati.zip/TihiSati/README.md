# Tihi sati

Mala Android aplikacija: obavijesti za odabrane WhatsApp razgovore zvone samo u zadanom vremenu (npr. Pon–Pet 08:00–16:00). Ostali razgovori zvone normalno.

## Kako radi
1. U WhatsAppu se zvuk i vibracija obavijesti isključe.
2. Aplikacija preko pristupa obavijestima vidi svaku novu WhatsApp poruku.
3. Ako razgovor nema pravilo, ili je unutar svog vremena, aplikacija pusti zvuk i vibraciju.
4. Ako je izvan vremena, obavijest ostaje tiha. Ako je za to pravilo uključeno "sakrij", obavijest se potpuno makne.

Poštuje "Ne ometaj" i način zvona (normalno / vibracija / nečujno). Pozive ne dira.

## Izgradnja APK-a

**A) GitHub (bez Android Studija)**
1. Napravi novi (može privatni) repozitorij i pushaj ovu mapu.
2. Actions → "Build APK" se pokrene sam.
3. Kad završi, preuzmi artefakt `TihiSati-apk` (zip u kojem je `app-debug.apk`).

**B) Android Studio**
Open → ova mapa → pričekaj sync → Run na spojenom mobitelu.

## Postavljanje na mobitelu
1. Instaliraj APK (dopusti instalaciju iz nepoznatih izvora).
2. **Android 13+:** Postavke → Aplikacije → Tihi sati → ⋮ (gore desno) → *Dopusti ograničene postavke*. Bez ovoga Android ne da uključiti pristup obavijestima aplikaciji instaliranoj izvan Play Storea.
3. U aplikaciji: korak 1, uključi pristup obavijestima za "Tihi sati".
4. Korak 2: u WhatsAppu, Postavke → Obavijesti, za Poruke i Grupe ton na "Ništa" i vibraciju isključi.
5. Dodaj razgovore: naziv točno kako piše u WhatsAppu (dovoljan je i dio naziva), vrijeme i dane.

## Ograničenja
- Zvuk je zadani zvuk obavijesti sustava, ne WhatsAppov.
- Pravilo se prepoznaje po nazivu razgovora. Ako dva razgovora imaju sličan naziv, upiši precizniji.
- Na nekim mobitelima (Xiaomi, Huawei, Samsung) isključi optimizaciju baterije za aplikaciju da je sustav ne ugasi.
